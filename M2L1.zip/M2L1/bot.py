import discord
from discord.ext import commands
import random, os, requests


description = '''Hola como estas?'''

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix='!', description=description, intents=intents)


@bot.event
async def on_ready():
    print(f'Logged in as {bot.user} (ID: {bot.user.id})')
    print('------')

    for guild in bot.guilds:
        for channel in guild.text_channels:
            if channel.name == 'general':
                try:
                    await channel.send('Hola, bienvenidos a mi bot ')
                except Exception as e:
                    print(f'No se puedo enviar el mensaje a {channel.name} : {e}')
                break


def get_duck_image_url():    
    url = 'https://api.imgflip.com/caption_image'
    res = requests.get(url)
    data = res.json()
    return data['url']


@bot.command('duck')
async def duck(ctx):
    '''Una vez que llamamos al comando duck, 
    el programa llama a la función get_duck_image_url'''
    image_url = get_duck_image_url()
    await ctx.send(image_url)

@bot.command()
async def mem(ctx):
    img_name = random.choice(os.listdir('M2L1/img'))
    with open(f'M2L1/img/{img_name}', 'rb') as f:
        # ¡Vamos a almacenar el archivo de la biblioteca Discord convertido en esta variable!
        picture = discord.File(f)
    # A continuación, podemos enviar este archivo como parámetro.
    await ctx.send(file=picture)



if __name__ == "__main__":
    token = os.getenv("MTM4NTk5MzYzOTkwOTM5NjQ5MA.GLX77H.O9A5Vwk9IJTSuHR98HZiMaqxOFEf71gs0Ptlvo")
    if not token:
        raise RuntimeError(token)
    bot.run(token)


