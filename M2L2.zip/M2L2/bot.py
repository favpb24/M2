import discord
from discord.ext import commands
import random, os, requests


description = '''Hola como estas?'''

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix='!', description=description, intents=intents)


@bot.event
async def on_ready():
    print(f'Logged in as {bot.user} (ID: {bot.user.id})')
    print('------')

    for guild in bot.guilds:
        for channel in guild.text_channels:
            if channel.name == 'general':
                try:
                    await channel.send(''' 
                                !info
                                📚 Muestra una breve explicación sobre qué es la contaminación y sus tipos (aire, agua, suelo, etc.).

                                !estadisticas
                                📊 Envía datos actuales o generales sobre la contaminación en el mundo (puedes usar datos fijos o actualizables si conectas APIs).

                                !consejos
                                ✅ Ofrece consejos prácticos para reducir la contaminación desde casa, escuela o comunidad.

                                !reto
                                🏆 Lanza un reto ecológico diario o semanal, como "Hoy no uses plástico" o "Planta una semilla".

                                !test
                                ❓ Un pequeño cuestionario con 3 o 5 preguntas sobre contaminación para que los usuarios aprendan de forma divertida.''')
                except Exception as e:
                    print(f'No se puedo enviar el mensaje a {channel.name} : {e}')
                break


@bot.command()
async def info(ctx):
    await ctx.send("📚 La contaminación es la presencia o acumulación de sustancias nocivas en el medio ambiente. Tipos comunes: aire, agua, suelo, lumínica y sonora.")

@bot.command()
async def estadisticas(ctx):
    await ctx.send("📊 Estadísticas de contaminación:\n- 9 de cada 10 personas respiran aire contaminado.\n- Más de 8 millones de toneladas de plástico llegan a los océanos cada año.")

@bot.command()
async def consejos(ctx):
    await ctx.send("✅ Consejos ecológicos:\n- Usa menos plástico.\n- Separa los residuos.\n- Ahorra agua y energía.\n- Usa transporte público o bicicleta.")

@bot.command()
async def reto(ctx):
    await ctx.send("🏆 Reto ecológico del día: ¡No uses bolsas plásticas hoy! Lleva una bolsa reutilizable.")

@bot.command()
async def test(ctx):
    await ctx.send("❓ ¡Pronto tendrás un test interactivo sobre contaminación! (función en desarrollo)")







if __name__ == "__main__":
    token = os.getenv("MTM4NTk5MzYzOTkwOTM5NjQ5MA.GLX77H.O9A5Vwk9IJTSuHR98HZiMaqxOFEf71gs0Ptlvo")
    if not token:
        raise RuntimeError(token)
    bot.run(token)
